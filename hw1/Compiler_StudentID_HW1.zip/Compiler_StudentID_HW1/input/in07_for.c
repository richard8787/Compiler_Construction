int x = 0;
for (x = 0; x < 10; x++) {
    print(x);
}