float foo(int a, float b) {
    return a+b;
}

void vv() {
    return;
}

int main() {
    print(foo(1, 0.2));
    return 0;
}