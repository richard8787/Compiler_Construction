int x;
int y;
x + y;
x - y;
x * y;
x / y;
x % y;
x++;
x--;