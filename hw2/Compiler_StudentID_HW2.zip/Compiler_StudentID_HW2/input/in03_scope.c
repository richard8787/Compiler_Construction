int height = 99;
int i = 1;
int j = 2;
while(i > 0){
    float width = 3.14;
}
float length;
while(i > 0){
    string length = "hello world";
    while(j > 0){
        bool lengh = true;
    }
    string width = "Hi, OuO\n";
}