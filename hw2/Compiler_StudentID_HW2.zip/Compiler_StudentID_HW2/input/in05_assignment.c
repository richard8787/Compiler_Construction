int x;
x = 1;
x += 2;
x -= 3;
x *= 4;
x /= 5;
x %= 6;

float yy = 3.14;
yy = 1.0;
yy += 2.0;
yy -= 3.0;
yy *= 4.0;
yy /= 5.0;

string s;
s = "Hello";

bool bbb =false;
bbb = true;

print(x);
print(yy);
print(s);
print(bbb);