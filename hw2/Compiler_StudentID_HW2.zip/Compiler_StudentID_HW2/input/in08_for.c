int x = 0;
x += 10;
while (x > 0) {
	print(x);
	x--;
}

int i;
for (i = 0; i < 10; i++) {
	print(i);
}