int x = 3;
float y = 3.14;
int z1;
float z2;
z1 = x + (int)y;
z2 = (float)x ;
print(z1);
print("\n");
print(z2);
print("\n");

z1 = x + (int)6.28;
z2 = (float)6 ;
print(z1);
print("\n");
print(z2);