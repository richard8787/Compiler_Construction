int x = 0;
// x += 10;
for(x=10 ; x > 0 ; x--){
	print("\n");
	print(x);
}