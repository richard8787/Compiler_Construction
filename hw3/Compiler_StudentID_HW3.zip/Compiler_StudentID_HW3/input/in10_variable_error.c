int  x;

float z;
int x;
y = 8;
8 += x;

int z;

if(gg > 0){
	print("gg");
}